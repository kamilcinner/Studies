<?php
function getRootPath() {
    return $_SERVER['DOCUMENT_ROOT'].'/';
}
