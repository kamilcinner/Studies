<?php
include 'utils/showPrettyStats.php';

$schema = ["C ", "C++", "Java ", "C#", "Html", "CSS", "XML", "PHP", "JavaScript"];

showPrettyStats($schema);
