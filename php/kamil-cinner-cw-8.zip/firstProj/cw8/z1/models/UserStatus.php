<?php

abstract class UserStatus {
    const STATUS_USER = 0;
    const STATUS_ADMIN = 1;
}
