<?php
echo "<h2>First PHP script</h2>";

$n = 5;
$x = 10.56;

// a
echo 'n = '.$n.",<br>x = ".$x,'<br><br>';

// b
echo "n = $n";
echo '<br>x = ${x}';
